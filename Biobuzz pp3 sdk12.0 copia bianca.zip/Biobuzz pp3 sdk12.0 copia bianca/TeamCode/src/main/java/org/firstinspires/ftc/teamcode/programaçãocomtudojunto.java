package org.firstinspires.ftc.teamcode;

import com.pedropathing.drivetrain.DrivePowers;
import com.pedropathing.follower.Follower;
import com.pedropathing.follower.ManualDrive;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;

import org.firstinspires.ftc.teamcode.pedro.Constants;

@TeleOp
public class programaçãocomtudojunto extends OpMode {
    DcMotor MA;
    DcMotor MT;
    DcMotor MI;
    public DcMotorEx flywheel;
    private Follower follower;
    double headingOffset = 0;
    boolean liga = false;
    double curTargetVelocity;

    @Override
    public void init() {
        MA = hardwareMap.get(DcMotor.class,"MA");
        MT = hardwareMap.get(DcMotor.class,"MT");
        MI = hardwareMap.get(DcMotor.class,"MI");

        follower = Constants.create(hardwareMap);

        flywheel = hardwareMap.get(DcMotorEx.class,"MO");
        flywheel.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        flywheel.setDirection(DcMotorSimple.Direction.REVERSE);
        PIDFCoefficients pidfCoefficients = new PIDFCoefficients(36,0,0,17.1);
        flywheel.setPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER,pidfCoefficients);
    }

    @Override
    public void loop() {
        outtake();
        base();
        ativador();
        torreta();
        intake();

        telemetry.addData("veocidade",flywheel.getVelocity());
    }

    public void outtake(){
        if(gamepad1.right_bumper){
            liga = true;
        }else {
            liga = false;
        }

        if(liga){
            curTargetVelocity = 1550;
        }else {
            curTargetVelocity = 0;
        }
        flywheel.setVelocity(curTargetVelocity);
    }

    public void base(){
        if(gamepad1.startWasPressed()){
            headingOffset = follower.pose().heading();
        }
        double driverHeading = follower.pose().heading() - headingOffset;
        DrivePowers powers = ManualDrive.fieldCentric(
                -gamepad1.left_stick_y,
                -gamepad1.left_stick_x,
                -gamepad1.right_stick_x,
                driverHeading
        );
        if (!gamepad1.a) {
            ManualDrive.driveOrHold(follower, powers);
        } else {
            ManualDrive.driveOrHold(follower, -gamepad1.left_stick_y, -gamepad1.left_stick_x, -gamepad1.right_stick_x);
        }
        follower.update();
    }

    public void ativador(){
        if(gamepad1.x){
            MA.setPower(0.7);
        }else if(gamepad1.b){
            MA.setPower(-0.7);
        }else{
            MA.setPower(0);
        }
    }

    public void torreta(){
        if(gamepad1.dpad_left){
            MT.setPower(-0.3);
        }else if(gamepad1.dpad_right){
            MT.setPower(0.3);
        }else {
            MT.setPower(0);
        }
    }

    public void intake(){
        if(gamepad1.left_bumper){
            MI.setPower(-1);
        }else if(gamepad1.dpad_down){
            MI.setPower(1);
        }else {
            MI.setPower(0);
        }
    }
}
