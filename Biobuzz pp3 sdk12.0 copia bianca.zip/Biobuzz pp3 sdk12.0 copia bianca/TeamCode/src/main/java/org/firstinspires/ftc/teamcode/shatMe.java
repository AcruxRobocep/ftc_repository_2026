package org.firstinspires.ftc.teamcode;

import static android.os.SystemClock.sleep;
import static com.pedropathing.ivy.commands.Commands.instant;
import static com.pedropathing.ivy.commands.Commands.waitMs;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;

@TeleOp
public class shatMe extends OpMode {
    DcMotor MA;
    public DcMotorEx flywheel;

    double highvelocity = 1500;
    double lowvelocity = 800;

    double curTargetVelocity = highvelocity;

    double F = 17.1;
    double P = 36;

    double[]stepSizes = {10, 1.0, 0.1, 0.01, 0.001};

    int stepIndex = 1;

    @Override
    public void init() {
        MA = hardwareMap.get(DcMotor.class,"MA");

        flywheel = hardwareMap.get(DcMotorEx.class,"MO");
        flywheel.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        flywheel.setDirection(DcMotorSimple.Direction.REVERSE);
        PIDFCoefficients pidfCoefficients = new PIDFCoefficients(36,0,0,17.1);
        flywheel.setPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER,pidfCoefficients);
    }

    @Override
    public void loop() {

        PIDFCoefficients pidfCoefficients = new PIDFCoefficients(P,0,0,F);
        flywheel.setPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER,pidfCoefficients);

        if(gamepad1.optionsWasPressed()) {

        }
    }
}
