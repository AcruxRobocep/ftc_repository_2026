package org.firstinspires.ftc.teamcode.FlywheelTuner;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
@TeleOp
public class kVTuner extends OpMode {
    Flywheel flywheel = new Flywheel();
    public static double kV = 0.000169;
    public double kS = 0.22;

    public double goalRPM = 1500;

    double[] increments = {0.00000001, 0.0000001, 0.000001, 0.00001, 0.0001};
    int incrementIdx = 0;

    @Override
    public void init() {
        flywheel.init(hardwareMap);
    }

    @Override
    public void loop() {
        if (gamepad1.dpadRightWasPressed() && incrementIdx < increments.length - 1){
            incrementIdx++;
        }else if(gamepad1.dpadLeftWasPressed() && incrementIdx > 0){
            incrementIdx--;
        }

        if(gamepad1.a){
            goalRPM = 1500;
        }else if(gamepad1.b){
            goalRPM = 800;
        }
        double currentStep = increments[incrementIdx];

        if (gamepad1.dpadUpWasPressed()){
            kV += currentStep; }
        if (gamepad1.dpadDownWasPressed()){
            kV -= currentStep; }

        double power = (kV * goalRPM) + kS;
        flywheel.setMotorPower(power);

        // Usando o formato nativo do telemetry para exibir sem notação científica
        telemetry.addData("currentStep", "%.10f", currentStep);
        telemetry.addData("kV", "%.8f", kV);
        telemetry.addData("RPM", flywheel.getRPM());
        telemetry.addData("ticksPerSec", flywheel.getTicksPerSecond());
    }
}
