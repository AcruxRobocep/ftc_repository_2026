package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.gobilda.GoBildaPinpointDriver;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;

//falar que esse codigo é um teleop e falar o nome dela
@TeleOp(name = "Field Relative Drive Top Das Galaxias")
//fala que esse opmode, ou seja, essa programação é um opmode
public class FieldRelativeDriveTopDasGalaxias extends OpMode {
    // declarar os objetos de classe motor(branco) e o nome (azul)
    DcMotor frontLeftDrive;
    DcMotor frontRightDrive;
    DcMotor backLeftDrive;
    DcMotor backRightDrive;
    //declara variavel top
    double HeadingLockAngle;

    //declara o objeto de classe do pinpoint da gobilda(branco) e o nome(azul)
    GoBildaPinpointDriver pinpoint;

    @Override
    public void init() {
        //linka cada motor com a sua versao definida no control hub
        //azul claro = nome do objeto motor do codigo, hardware map é o tipo de objeto, azul escuro fala que a classe é um motor e verde é o nome do motor no control hub, ou seja, o nome da versao fisica
        frontLeftDrive = hardwareMap.get(DcMotor.class, "LF");
        frontRightDrive = hardwareMap.get(DcMotor.class, "RF");
        backLeftDrive = hardwareMap.get(DcMotor.class, "LB");
        backRightDrive = hardwareMap.get(DcMotor.class, "RB");

        //fala a direçao que cada motor tem que girar
        backRightDrive.setDirection(DcMotor.Direction.REVERSE);
        backLeftDrive.setDirection(DcMotorSimple.Direction.FORWARD);
        frontLeftDrive.setDirection(DcMotor.Direction.REVERSE);
        frontRightDrive.setDirection(DcMotor.Direction.REVERSE);

        //faz a mesma coisa que o da linha 28, mas para o pinpoint
        pinpoint = hardwareMap.get(GoBildaPinpointDriver.class, "pinpoint");

        //reseta o imu do pinpoint e a variavel que fala o angulo que o robo tem que ficar, pois nao da pra deixar ela vazia quando iniciar o codigo
        pinpoint.resetPosAndIMU();
        HeadingLockAngle = 0;
    }

    @Override
    public void loop() {
        //atualiza o heading do pinpoint para o codigo, ja que o pinpoint funciona como um computador
        //separado que fica funcionando o tempo todo calculando a posição do robo
        //entao o codigo so precisa pedir as informações pra ele usando esse comando
        //fiz ele so atualizar o heading para o loop não ter tanto delay, ja que ele nao tem que pegar todas as informações
        pinpoint.update(GoBildaPinpointDriver.ReadData.ONLY_UPDATE_HEADING);

        //pega o heading do pinpoint como valores e o transforma em variaveis
        //em radianos
        double headingRadians = pinpoint.getHeading(AngleUnit.RADIANS);

        //telemetria bacanuda pro piloto saber o que fazer e poder ver as informações do robo
        //telemtria são informações que aparecem no terminal, mas nesse caso, aparecem no driver hub pro piloto poder ver
        //é bem util para testar e ver o que há de errado quando algo da errado

        //quando o botao "a" é apertado ele define a direção do field relative drive para a direção que ele esta apontado agora
        //pois o grau 0 é o grau na frente do robo, ja que vai de -180 a 180
        if (gamepad1.aWasPressed()) {
            //aqui ele usa o comando set heading ao inves do reset imu, ja que o reset poseandimu come muito processamento
            //entao é melhor apenas definir o heading atual como 0
            pinpoint.setHeading(0, AngleUnit.DEGREES);
            HeadingLockAngle = 0;
        }

        //se o botao left bumper for pressionado ele dirige o robo da forma relativa ao robo
        if (gamepad1.left_bumper) {
            //chama a função de movimentação
            // ela dirige relativa ao campo por que ainda nao passou pela conversão de realiva ao campo, entao recebe os valores raw, ou seja, crus.
            drive(-gamepad1.left_stick_y, gamepad1.left_stick_x, gamepad1.right_stick_x);
        //senao ele dirige relativa ao campo
        } else {
            //chama a função que converte os valores do gamepad e a direção do robô nas que são relativas ao campo
            FieldRelativeMovimentationValueConversion(-gamepad1.left_stick_y, gamepad1.left_stick_x, gamepad1.right_stick_x, headingRadians);
        }
    }

    //função que converte os valores de joystick e heading dados em novos valores para a nova força dos motores, que faz com que o robo se mexa na direção almejada
    private void FieldRelativeMovimentationValueConversion(double forward, double right, double rotate, double headingRadians) {
        //primeiro, converter os valores do joystick esquerdo, que é a movimentação, para coordenadas polares
        //um sistema de coordenadas semelhante ao plano cartesiano, mas que ao inves das coordenadas envolverem "x" e "y", elas envolvem a distância e o ângulo

        //isso serve para determinar em que direção o piloto esta apontando o joystick, ou seja, apenas o angulo
        double theta = Math.atan2(forward, right);
        //calcula a distancia que o joystick esta do centro, ou seja, o valor de  distancia das coordenadas polares
        //este valor vai ser usado para determinar a força do movimento do robo
        double r = Math.hypot(right, forward);

        //converte a direção em que o piloto esta apontando o joystick, ou seja, theta, para a direção que el robô precisa ir para se mexer nessa direção
        //o AngleUnit.normalizeRadians é uma função que tranforma um valor que esteja de 0 a 360  que esteja entre -180 a 180, pois é assim que o robô entende a movimentação
        theta = AngleUnit.normalizeRadians(theta - headingRadians);

        //convertemos as coordenadas polares de volta para corrdenadas cartesianas
        //usando seno e cosseno, igual aprendido na sala de aula
        // já que coordenadas polares funcionam como se fosse uma cebola, com circulos dentro de circulos
        //multiplicamos por "r", ja que é a força
        double newForward = r * Math.sin(theta);
        double newRight = r * Math.cos(theta);

        //aqui começamos a fazer um sistema de travar o heading do robo usando um pid simplificado
        //pegamos o heading do robo
        double headingDegrees = pinpoint.getHeading(AngleUnit.DEGREES);
        //criamos a variavel NewRotate, para girar o robo
        //definimos ela como rotate, para que se o right bumper nao for apertado, ele gira normalmente
        double NewRotate = rotate;

        //valida apenas no primeiro tick em que o right bumper é apertado, não durante todo o periodo em que ele é apertado
        //usamos isso para que apenas no momento em que apertarmos, ele defina o angulo do headingLock durante todo o periodo em que ele estiver apertado
        if (gamepad1.rightBumperWasPressed()) {
            //ele trava o robo no angulo atual
            HeadingLockAngle = headingDegrees;
        }
        //enquanto o right bumper estiver sendo apertado, ele trava o robo no angulo que esta definido no heading lock
        if (gamepad1.right_bumper) {
            //sistema de PID que recebe o erro do angulo e o converte para a força de rotação necessaria para corrigir
            NewRotate = ((AngleUnit.normalizeDegrees(headingDegrees - HeadingLockAngle)) * 0.0333);
        }

        //chama o metodo que liga os motores igual uma movimentação mecanum normal
        //mas com os valores atualizados, para que o robo vá na direção almejada
        drive(newForward, newRight, NewRotate);
    }

    //metodo de dirijição normal de rodas mecanum
    //isso ai vem pronto, so traduzir ou pesquisar como funciona na net
    public void drive(double forward, double right, double rotate) {
        // This calculates the power needed for each wheel based on the amount of forward,
        // strafe right, and rotate
        double frontLeftPower = forward + right + rotate;
        double frontRightPower = forward - right - rotate;
        double backRightPower = forward + right - rotate;
        double backLeftPower = forward - right + rotate;

        double maxPower = 1.0;
        double maxSpeed = 1.0;  // make this slower for outreaches

        // This is needed to make sure we don't pass > 1.0 to any wheel
        // It allows us to keep all of the motors in proportion to what they should
        // be and not get clipped
        maxPower = Math.max(maxPower, Math.abs(frontLeftPower));
        maxPower = Math.max(maxPower, Math.abs(frontRightPower));
        maxPower = Math.max(maxPower, Math.abs(backRightPower));
        maxPower = Math.max(maxPower, Math.abs(backLeftPower));

        // We multiply by maxSpeed so that it can be set lower for outreaches
        // When a young child is driving the robot, we may not want to allow full
        // speed.
        frontLeftDrive.setPower(maxSpeed * (frontLeftPower / maxPower));
        frontRightDrive.setPower(maxSpeed * (frontRightPower / maxPower));
        backLeftDrive.setPower(maxSpeed * (backLeftPower / maxPower));
        backRightDrive.setPower(maxSpeed * (backRightPower / maxPower));
    }
}
