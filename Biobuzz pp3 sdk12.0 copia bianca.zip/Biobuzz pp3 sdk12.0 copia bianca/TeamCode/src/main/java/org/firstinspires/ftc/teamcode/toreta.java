package org.firstinspires.ftc.teamcode;

import com.pedropathing.follower.Follower;
import com.pedropathing.math.Pose;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.teamcode.pedro.Constants;

/**
 * OpMode TeleOp para rastreamento da Hive utilizando a Odometria do Pedro Pathing (Pinpoint Localizer).
 * A torreta (MT) é controlada automaticamente para ficar sempre apontada para as coordenadas
 * da Hive no campo (HIVE_X, HIVE_Y), independentemente da posição ou rotação do robô.
 */
@TeleOp(name = "Toreta - Seguir Hive (Odometria)")
public class toreta extends LinearOpMode {

    // Motores do Drivetrain (Mecanum)
    private DcMotor frontLeftDrive;
    private DcMotor frontRightDrive;
    private DcMotor backLeftDrive;
    private DcMotor backRightDrive;
    private DcMotorEx flywheel;

    // Motor da Torreta (MT)
    private DcMotor MT;
    private DcMotor MA;

    // Seguidor Pedro Pathing (usando a odometria Pinpoint configurada em Constants.java)
    private Follower follower;

    // Coordenadas da Hive (Alvo) no campo (em polegadas)
    public static double HIVE_X = 84.0;
    public static double HIVE_Y = 72.0;

    // Posição Inicial Estimada do Robô no campo
    public static double START_X = 84.0;
    public static double START_Y = 8.0;
    public static double START_HEADING_DEG = 90.0;

    // Conversão do Encoder do motor da torreta (MT)
    public static double TICKS_PER_REV = 288.0;
    public static double GEAR_RATIO = 2.75; // Redução externa entre motor e torreta
    public static double TICKS_PER_RADIAN = (TICKS_PER_REV * GEAR_RATIO) / (2.0 * Math.PI);

    // Configurações de inversão de direção
    public static boolean INVERT_TURRET_MOTOR = false;
    public static boolean INVERT_ENCODER = false;

    // Limite Máximo de Rotação da Torreta (170° para esquerda e -170° para direita)
    public static double MAX_TURRET_ANGLE_DEG = 170.0;

    // Controle PID da Torreta (Proporcional + Integral + Derivativo + Feedforward) - Agressivo e Preciso
    public static double kP = 1.50; // Ganho Proporcional mais agressivo para resposta rápida
    public static double kI = 0.05; // Ganho Integral para eliminar erro estático de posição
    public static double kD = 0.08; // Ganho Derivativo ajustado para evitar over-shooting
    public static double kF = 0.02; // Feedforward (mínimo de potência para vencer atrito estático)
    public static double MAX_TURRET_POWER = 1.0;
    public static double ANGLE_TOLERANCE_DEG = 0.5; // Tolerância angular reduzida para 0.5° (maior precisão)

    // Offset do eixo da torreta em relação à origem do Pinpoint (em polegadas).
    public static double TURRET_OFFSET_X = -10.0 / 2.54; // = -3.937 in (ATRÁS)
    public static double TURRET_OFFSET_Y = -6.5 / 2.54;  // = -2.559 in (DIREITA)

    private boolean autoTargetHiveEnabled = true;
    private double lastAngleErrorRad = 0.0;
    private double integralSum = 0.0;
    private long lastTimeNs = 0;

    DcMotor MI;

    @Override
    public void runOpMode() throws InterruptedException {
        // Inicialização dos motores do Drivetrain (Mecanum básico)
        frontLeftDrive = hardwareMap.get(DcMotor.class, "LF");
        frontRightDrive = hardwareMap.get(DcMotor.class, "RF");
        backLeftDrive = hardwareMap.get(DcMotor.class, "LB");
        backRightDrive = hardwareMap.get(DcMotor.class, "RB");

        backRightDrive.setDirection(DcMotor.Direction.REVERSE);
        backLeftDrive.setDirection(DcMotorSimple.Direction.FORWARD);
        frontLeftDrive.setDirection(DcMotor.Direction.REVERSE);
        frontRightDrive.setDirection(DcMotor.Direction.REVERSE);

        frontLeftDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        frontRightDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        backLeftDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        backRightDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        MA = hardwareMap.get(DcMotor.class,"MA");
        MI = hardwareMap.get(DcMotor.class,"MI");

        // Inicialização do motor da Torreta (MT)
        MT = hardwareMap.get(DcMotor.class, "MT");
        MT.setDirection(INVERT_TURRET_MOTOR ? DcMotor.Direction.REVERSE : DcMotor.Direction.FORWARD);
        MT.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        // Reseta o encoder da torreta assumindo que a torreta inicia apontada para a FRENTE (0°)
        MT.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        MT.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        // Inicialização do Pedro Pathing (usando as configurações de odometria do Auto em Constants)
        follower = Constants.create(hardwareMap);
        follower.setPose(new Pose(START_X, START_Y, Math.toRadians(START_HEADING_DEG)));

        telemetry.addLine(">> Pedro Pathing Odometry & Turret Initialized.");
        telemetry.addLine(">> Garanta que a torreta está virada para a FRENTE antes de pressionar START!");
        telemetry.update();

        flywheel = hardwareMap.get(DcMotorEx.class,"MO");
        flywheel.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        flywheel.setDirection(DcMotorSimple.Direction.REVERSE);
        PIDFCoefficients pidfCoefficients = new PIDFCoefficients(36,0,0,17.1);
        flywheel.setPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER,pidfCoefficients);

        waitForStart();

        while (opModeIsActive()) {
            // Atualiza o Pedro Pathing (odometria Pinpoint)
            follower.update();

            Pose currentPose = follower.pose();
            double robotX = currentPose.x();
            double robotY = currentPose.y();
            double robotHeadingRad = currentPose.heading();
            double robotHeadingDeg = Math.toDegrees(robotHeadingRad);

            // Botão A: Reseta o Heading mantendo a posição X, Y e zerando a orientação
            if (gamepad1.aWasPressed()) {
               // follower.setPose(new Pose(robotX, robotY, 0));
            }

            if(gamepad1.left_bumper){
                flywheel.setVelocity(1700);
            }else {
                flywheel.setVelocity(0);
            }
            if(gamepad1.b){
                MA.setPower(-0.8);
            }else {
                MA.setPower(0);
            }

            MI.setPower(gamepad1.right_bumper ? -1 :0);

            // Botão X: Alterna entre Modo Automático (Seguir Hive) e Manual
            if (gamepad1.startWasPressed()) {
                autoTargetHiveEnabled = !autoTargetHiveEnabled;
            }

            // Botão D-Pad Up: Re-zera a torreta na frente
            if (gamepad1.dpadUpWasPressed()) {
                MT.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
                MT.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            }

            // -------------------------------------------------------------
            // 1. PILOTAGEM (Movimentação Robô-Cêntrica Básica)
            // -------------------------------------------------------------
            driveRobotCentric(-gamepad1.left_stick_y, gamepad1.left_stick_x, gamepad1.right_stick_x);

            // -------------------------------------------------------------
            // 2. RASTREAMENTO DA HIVE VIA ODOMETRIA PEDRO PATHING
            // -------------------------------------------------------------
            if (autoTargetHiveEnabled && !gamepad1.dpad_left && !gamepad1.dpad_right) {
                atualizarTorretaSeguirHive(robotX, robotY, robotHeadingRad);
            } else {
                // Controle manual via D-Pad Esquerda/Direita
                if (gamepad1.dpad_left) {
                    MT.setPower(-0.3);
                } else if (gamepad1.dpad_right) {
                    MT.setPower(0.3);
                } else {
                    MT.setPower(0);
                }
            }

            // -------------------------------------------------------------
            // 3. TELEMETRIA
            // -------------------------------------------------------------
            telemetry.addData("--- ODOMETRIA PEDRO PATHING ---", "");
            telemetry.addData("Robô Pos X", "%.2f in", robotX);
            telemetry.addData("Robô Pos Y", "%.2f in", robotY);
            telemetry.addData("Robô Heading", "%.1f°", robotHeadingDeg);

            telemetry.addData("--- ALVO (HIVE) ---", "");
            telemetry.addData("Hive Pos (X, Y)", "(%.1f, %.1f)", HIVE_X, HIVE_Y);

            telemetry.addData("--- TORRETA ---", "");
            telemetry.addData("Modo Torreta", autoTargetHiveEnabled ? "AUTOMÁTICO (SEGUINDO HIVE)" : "MANUAL");
            telemetry.addData("Torreta Ângulo Atual", "%.1f°", Math.toDegrees(getCurrentTurretAngleRad()));
            telemetry.addData("Torreta Ticks Encoder", MT.getCurrentPosition());

            telemetry.update();
        }
    }

    /**
     * Calcula o ângulo da torreta em radianos baseado na leitura do encoder.
     * 0 Radianos = Torreta Apontada para a FRENTE do robô.
     */
    private double getCurrentTurretAngleRad() {
        double directionMultiplier = INVERT_ENCODER ? -1.0 : 1.0;
        return (directionMultiplier * MT.getCurrentPosition()) / TICKS_PER_RADIAN;
    }

    /**
     * Geometria e controle PID agressivo da torreta para rastrear a Hive por Odometria.
     */
    private void atualizarTorretaSeguirHive(double robotX, double robotY, double robotHeadingRad) {
        // 1. Posição global da torreta no campo (com offset do robô).
        double turretX = robotX + (TURRET_OFFSET_X * Math.cos(robotHeadingRad) - TURRET_OFFSET_Y * Math.sin(robotHeadingRad));
        double turretY = robotY + (TURRET_OFFSET_X * Math.sin(robotHeadingRad) + TURRET_OFFSET_Y * Math.cos(robotHeadingRad));

        // 2. Vetor até a Hive
        double dX = HIVE_X - turretX;
        double dY = HIVE_Y - turretY;
        double distanceToHive = Math.hypot(dX, dY);

        // 3. Ângulo absoluto no campo até a Hive
        double fieldAngleToHive = Math.atan2(dY, dX);

        // 4. Ângulo relativo da Hive em relação à FRENTE do robô (-180° a +180°)
        double targetTurretAngleRad = AngleUnit.normalizeRadians(fieldAngleToHive - robotHeadingRad);
        double targetTurretAngleDeg = Math.toDegrees(targetTurretAngleRad);

        // 5. PROTEÇÃO DE LIMITES DA TORRETA (+170° a -170°)
        if (targetTurretAngleDeg > MAX_TURRET_ANGLE_DEG) {
            targetTurretAngleRad = Math.toRadians(MAX_TURRET_ANGLE_DEG);
        } else if (targetTurretAngleDeg < -MAX_TURRET_ANGLE_DEG) {
            targetTurretAngleRad = Math.toRadians(-MAX_TURRET_ANGLE_DEG);
        }

        // 6. Ângulo atual do encoder da torreta
        double currentTurretAngleRad = getCurrentTurretAngleRad();
        double currentTurretAngleDeg = Math.toDegrees(currentTurretAngleRad);

        // 7. Erro angular SEM normalização
        double angleErrorRad = targetTurretAngleRad - currentTurretAngleRad;
        double angleErrorDeg = Math.toDegrees(angleErrorRad);

        // 8. CÁLCULO PID (PROPORCIONAL + INTEGRAL + DERIVATIVO + FEEDFORWARD)
        long currentTimeNs = System.nanoTime();
        double dt = (currentTimeNs - lastTimeNs) / 1e9;
        if (dt <= 0 || dt > 0.2) dt = 0.02;

        double dError = (angleErrorRad - lastAngleErrorRad) / dt;

        if (Math.signum(angleErrorRad) != Math.signum(lastAngleErrorRad)) {
            integralSum = 0.0;
        }

        if (Math.abs(angleErrorDeg) < 20.0) {
            integralSum += angleErrorRad * dt;
            integralSum = Math.max(-0.2, Math.min(0.2, integralSum));
        } else {
            integralSum = 0.0;
        }

        lastAngleErrorRad = angleErrorRad;
        lastTimeNs = currentTimeNs;

        // 9. Aplicação do Controle PID Agressivo
        double turretPower;
        if (Math.abs(angleErrorDeg) >= ANGLE_TOLERANCE_DEG) {
            double pTerm = angleErrorRad * kP;
            double iTerm = integralSum * kI;
            double dTerm = dError * kD;
            double fTerm = Math.signum(angleErrorRad) * kF;

            turretPower = pTerm + iTerm + dTerm + fTerm;
            turretPower = Math.max(-MAX_TURRET_POWER, Math.min(MAX_TURRET_POWER, turretPower));
            telemetry.addData("Status Torreta", "Mirando na Hive...");
        } else {
            turretPower = 0.0;
            integralSum = 0.0;
            telemetry.addData("Status Torreta", "ALINHADO NA HIVE!");
        }

        MT.setPower(turretPower);

        telemetry.addData("Torreta Pos Campo (X, Y)", "(%.1f, %.1f)", turretX, turretY);
        telemetry.addData("Distância até a Hive", "%.2f in", distanceToHive);
        telemetry.addData("Torreta Ângulo Alvo", "%.1f°", Math.toDegrees(targetTurretAngleRad));
        telemetry.addData("Torreta Ângulo Atual", "%.1f°", currentTurretAngleDeg);
        telemetry.addData("Torreta Erro Angular", "%.1f°", angleErrorDeg);
        telemetry.addData("Potência Torreta", "%.2f", turretPower);
    }

    /**
     * Aplicação básica de potência nas 4 rodas mecanum (Robot-Centric).
     */
    private void driveRobotCentric(double forward, double right, double rotate) {
        double frontLeftPower = forward + right + rotate;
        double frontRightPower = forward - right - rotate;
        double backRightPower = forward + right - rotate;
        double backLeftPower = forward - right + rotate;

        double maxPower = Math.max(1.0, Math.abs(frontLeftPower));
        maxPower = Math.max(maxPower, Math.abs(frontRightPower));
        maxPower = Math.max(maxPower, Math.abs(backRightPower));
        maxPower = Math.max(maxPower, Math.abs(backLeftPower));

        frontLeftDrive.setPower(frontLeftPower / maxPower);
        frontRightDrive.setPower(frontRightPower / maxPower);
        backLeftDrive.setPower(backLeftPower / maxPower);
        backRightDrive.setPower(backRightPower / maxPower);
    }
}
