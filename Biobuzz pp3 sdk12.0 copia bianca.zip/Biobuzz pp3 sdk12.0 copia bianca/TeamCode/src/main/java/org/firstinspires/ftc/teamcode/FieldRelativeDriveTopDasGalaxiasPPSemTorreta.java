package org.firstinspires.ftc.teamcode;

import com.pedropathing.drivetrain.DrivePowers;
import com.pedropathing.follower.Follower;
import com.pedropathing.follower.ManualDrive;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.teamcode.pedro.Constants;

@TeleOp(name = "Field Relative Drive Top Das GalaxiasPPsemtorreta")
public class FieldRelativeDriveTopDasGalaxiasPPSemTorreta extends OpMode {

    DcMotor MT;
    private Follower follower;
    boolean RobotCentric = false;
    double headingOffset = 0;
    @Override
    public void init() {
        MT = hardwareMap.get(DcMotor.class,"MT");
        follower = Constants.create(hardwareMap);
    }
    @Override
    public void loop() {
        if(gamepad1.options){
            headingOffset = follower.pose().heading();
        }
        double driverHeading = follower.pose().heading() - headingOffset;
        DrivePowers powers = ManualDrive.fieldCentric(
                -gamepad1.left_stick_y,
                -gamepad1.left_stick_x,
                -gamepad1.right_stick_x,
                driverHeading
        );

        if(gamepad1.backWasPressed()){
            RobotCentric = !RobotCentric;
        }

        if (!RobotCentric) {
            ManualDrive.driveOrHold(follower, powers);
        } else {
            ManualDrive.driveOrHold(follower, -gamepad1.left_stick_y, -gamepad1.left_stick_x, -gamepad1.right_stick_x);
        }
        follower.update();
    }
}