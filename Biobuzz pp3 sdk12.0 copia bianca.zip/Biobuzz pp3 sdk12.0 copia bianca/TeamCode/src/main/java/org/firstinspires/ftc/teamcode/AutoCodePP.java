package org.firstinspires.ftc.teamcode;

import com.pedropathing.api.Paths;

import com.pedropathing.api.PoseFactory;
import com.pedropathing.follower.Follower;
import com.pedropathing.math.Pose;
import com.pedropathing.paths.Path;
import com.pedropathing.ivy.Command;
import com.pedropathing.ivy.Scheduler;
import static com.pedropathing.ivy.Scheduler.schedule;
import static com.pedropathing.ivy.commands.Commands.*;
import static com.pedropathing.ivy.groups.Groups.sequential;
import static com.pedropathing.ivy.pedro.PedroCommands.follow;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;

import org.firstinspires.ftc.teamcode.pedro.Constants;

@Autonomous(name = "AutoPath", group = "Autonomous")
public class AutoCodePP extends LinearOpMode {
    private Follower follower;
    private final PoseFactory poseFactory = PoseFactory.degrees();
    private final Pose start = poseFactory.of(8, 83, 0);
    private final Pose goToShootFirstLoad = poseFactory.of(60, 10, 90);
    private final Pose alignFirstFlowerStart = poseFactory.of(60, 10, 90);
    private final Pose alignFirstFlower = poseFactory.of(18, 46, 180);
    private final Pose takeFirstFlower = poseFactory.of(9, 46, 180);
    private final Pose goToShootSecondLoadStart = poseFactory.of(9, 46, 180);
    private final Pose goToShootSecondLoad = poseFactory.of(60, 130, 270);
    private final Pose goToShootSecondLoadControl1 = poseFactory.of(22, 89, 0);
    private final Pose alignSecondFlowerStart = poseFactory.of(60, 130, 270);
    private final Pose alignSecondFlower = poseFactory.of(46, 123, 90);
    private final Pose takeSecondFlower = poseFactory.of(47, 132, 90);
    private final Pose goToShootThirdLoadStart = poseFactory.of(47, 132, 90);
    private final Pose goToShootThirdLoad = poseFactory.of(60, 133, 270);
    private final Pose goToShootThirdLoadControl1 = poseFactory.of(47, 103, 0);
    private final Pose park = poseFactory.of(11, 100, 270);
    private final Pose parkControl1 = poseFactory.of(4, 101, 0);
    private DcMotor MA;
    private DcMotorEx MO;

    // Autonomous routine
    public Command autoRoutine() {
        return sequential(
                follow(follower, goToShootFirstLoad()),
                //shoot
                shoot(),
                follow(follower, alignFirstFlower()),
                //velocidade baixa
                setPathVelocity(0.2),
                follow(follower, takeFirstFlower()),
                setPathVelocity(1),
                //velocidade alta
                follow(follower, goToShootSecondLoad()),
                //shoot
                shoot(),
                follow(follower, alignSecondFlower()),
                //velocidade baixa
                setPathVelocity(0.2),
                follow(follower, takeSecondFlower()),
                setPathVelocity(1),
                //velocidade alta
                follow(follower, goToShootThirdLoad()),
                //shoot
                shoot(),
                follow(follower, park())
        );
    }

    @Override
    public void runOpMode() {
        Scheduler.reset();
        follower = Constants.create(hardwareMap);
        follower.setPose(start);
        follower.update();

        MA = hardwareMap.get(DcMotor.class, "MA");
        MO = hardwareMap.get(DcMotorEx.class, "MO");

        PIDFCoefficients pidfCoefficients = new PIDFCoefficients(36,0,0,17.1);
        MO.setPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER,pidfCoefficients);

        waitForStart();
        schedule(autoRoutine());

        while (opModeIsActive()) {
            follower.update();
            Scheduler.execute();

            telemetry.addData("x", follower.pose().x());
            telemetry.addData("y", follower.pose().y());
            telemetry.addData("heading", follower.pose().heading());

            if (follower.currentPath() != null) {
                telemetry.addData("Current path distance remaining", follower.distanceToEndpoint());
                telemetry.addData("Path number", follower.pathIndex());
            }

            telemetry.update();
        }
    }

    public Path goToShootFirstLoad() {
        return Paths.line(start, goToShootFirstLoad).linear(start, goToShootFirstLoad);
    }

    public Path alignFirstFlower() {
        return Paths.line(alignFirstFlowerStart, alignFirstFlower).linear(alignFirstFlowerStart, alignFirstFlower);
    }

    public Path takeFirstFlower() {
        return Paths.line(alignFirstFlower, takeFirstFlower).constant(takeFirstFlower);
    }

    public Path goToShootSecondLoad() {
        return Paths.curve(goToShootSecondLoadStart, goToShootSecondLoadControl1, goToShootSecondLoad).linear(goToShootSecondLoadStart, goToShootSecondLoad);
    }

    public Path alignSecondFlower() {
        return Paths.line(alignSecondFlowerStart, alignSecondFlower).linear(alignSecondFlowerStart, alignSecondFlower);
    }

    public Path takeSecondFlower() {
        return Paths.line(alignSecondFlower, takeSecondFlower).constant(takeSecondFlower);
    }

    public Path goToShootThirdLoad() {
        return Paths.curve(goToShootThirdLoadStart, goToShootThirdLoadControl1, goToShootThirdLoad).linear(goToShootThirdLoadStart, goToShootThirdLoad);
    }

    public Path park() {
        return Paths.curve(goToShootThirdLoad, parkControl1, park).constant(park);
    }

    public Command setPathVelocity(double velocity) {
        return instant(() -> Constants.foresightConfig.maxPathSpeed.set(velocity));
    }

    public Command shoot() {
        return sequential(
                instant(() -> MO.setVelocity(1500)),
                waitMs(300),
                instant(() -> MA.setPower(1.0)),
                waitMs(3000),
                instant(() -> MO.setPower(0)),
                instant(() -> MA.setPower(0))
        );
    }
}