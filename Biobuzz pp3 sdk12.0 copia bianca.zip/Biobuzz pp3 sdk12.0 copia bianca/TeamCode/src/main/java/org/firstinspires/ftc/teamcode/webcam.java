package org.firstinspires.ftc.teamcode;

import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.hardwareMap;
import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.telemetry;

import android.util.Size;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.vision.VisionPortal;
import org.firstinspires.ftc.vision.apriltag.AprilTagDetection;
import org.firstinspires.ftc.vision.apriltag.AprilTagSingleDetection;
import org.firstinspires.ftc.vision.apriltag.AprilTagProcessor;
@TeleOp
public class webcam extends LinearOpMode {

    AprilTagProcessor aprilTag;
    VisionPortal visionPortal;
    DcMotor turretMotor;

    @Override
    public void runOpMode() {
        // Inicializa a câmera e o motor da torreta ("MT" no HardwareMap)
        aprilTag = new AprilTagProcessor.Builder().build();

        visionPortal = new VisionPortal.Builder()
                .setCamera(hardwareMap.get(WebcamName.class, "Webcam 1"))
                .setCameraResolution(new Size(1280, 960))
                .addProcessor(aprilTag)
                .build();

        try {
            turretMotor = hardwareMap.get(DcMotor.class, "MT");
            turretMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        } catch (Exception e) {
            turretMotor = null;
        }

        int targetTag1 = 39; // ID da primeira AprilTag
        int targetTag2 = 40; // ID da segunda AprilTag

        telemetry.addData("Status", "Aguardando início. Mirando entre Tags %d e %d", targetTag1, targetTag2);
        telemetry.update();

        waitForStart();

        while (opModeIsActive()) {
            // Executa o método para mirar no ponto médio entre as duas tags
            aimTurretBetweenTags(targetTag1, targetTag2);
            telemetry.update();
        }

        visionPortal.close();
    }

    /**
     * Método para focar a torreta no ponto médio entre duas AprilTags especificadas.
     * @param targetId1 ID da primeira AprilTag
     * @param targetId2 ID da segunda AprilTag
     */
    public void aimTurretBetweenTags(int targetId1, int targetId2) {
        AprilTagSingleDetection tag1 = null;
        AprilTagSingleDetection tag2 = null;

        for (AprilTagDetection detection : aprilTag.getDetections()) {
            if (detection instanceof AprilTagSingleDetection) {
                AprilTagSingleDetection singleDet = (AprilTagSingleDetection) detection;

                if (singleDet.ftcPose != null) {
                    if (singleDet.id == targetId1) {
                        tag1 = singleDet;
                    } else if (singleDet.id == targetId2) {
                        tag2 = singleDet;
                    }
                }
            }
        }

        if (tag1 != null && tag2 != null) {
            double tx1 = tag1.ftcPose.x;
            double tx2 = tag2.ftcPose.x;

            // Calcula o ponto médio horizontal entre as duas tags
            double middleX = (tx1 + tx2) / 2.0;

            telemetry.addData("Status", "Ambas as tags encontradas! (%d e %d)", targetId1, targetId2);
            telemetry.addData("Tag %d X", "%.1f in", targetId1, tx1);
            telemetry.addData("Tag %d X", "%.1f in", targetId2, tx2);
            telemetry.addData("Ponto Médio X", "%.1f in", middleX);

            // Controle Proporcional (Kp) para a torreta
            double Kp = 0.05;
            double power = middleX * Kp;

            // Limita a potência máxima do motor
            double maxPower = 0.3;
            power = Math.max(-maxPower, Math.min(maxPower, power));

            // Para o motor se estiver centralizado dentro de 0.5 in
            if (Math.abs(middleX) < 0.5) {
                power = 0.0;
            }

            if (turretMotor != null) {
                turretMotor.setPower(power);
            }
            telemetry.addData("Torreta Power", "%.2f", power);
        } else if (tag1 != null) {
            telemetry.addData("Status", "Apenas Tag %d visível", targetId1);
            if (turretMotor != null) turretMotor.setPower(0.0);
        } else if (tag2 != null) {
            telemetry.addData("Status", "Apenas Tag %d visível", targetId2);
            if (turretMotor != null) turretMotor.setPower(0.0);
        } else {
            telemetry.addData("Status", "Procurando Tags %d e %d...", targetId1, targetId2);
            if (turretMotor != null) turretMotor.setPower(0.0);
        }
    }

    /**
     * Método para focar a torreta em uma AprilTag específica usando Feedback Proporcional (PF).
     * @param targetId ID da AprilTag desejada
     */
    public void aimTurretAtTag(int targetId) {
        boolean tagFound = false;
        double tx = 0.0;

        for (AprilTagDetection detection : aprilTag.getDetections()) {
            if (detection instanceof AprilTagSingleDetection) {
                AprilTagSingleDetection singleDet = (AprilTagSingleDetection) detection;

                if (singleDet.id == targetId && singleDet.ftcPose != null) {
                    tagFound = true;
                    tx = singleDet.ftcPose.x; // Deslocamento horizontal (tx) em polegadas
                    double tz = singleDet.ftcPose.z; // Distância / elevação (tz)

                    telemetry.addData("Alvo Encontrado", "Tag ID: %d", targetId);
                    telemetry.addData("X (tx)", "%.1f in", tx);
                    telemetry.addData("Z (tz)", "%.1f in", tz);
                    break;
                }
            }
        }

        if (tagFound) {
            double Kp = 0.05;
            double power = tx * Kp;
            double maxPower = 0.3;
            power = Math.max(-maxPower, Math.min(maxPower, power));

            if (Math.abs(tx) < 0.5) {
                power = 0.0;
            }

            if (turretMotor != null) {
                turretMotor.setPower(power);
            }
            telemetry.addData("Torreta Power", "%.2f", power);
        } else {
            if (turretMotor != null) turretMotor.setPower(0.0);
            telemetry.addData("Status", "Procurando Tag ID %d...", targetId);
        }
    }
}
