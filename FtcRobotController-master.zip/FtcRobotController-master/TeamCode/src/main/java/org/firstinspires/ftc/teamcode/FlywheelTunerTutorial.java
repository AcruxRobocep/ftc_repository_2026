package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;

@TeleOp
public class FlywheelTunerTutorial extends OpMode {
    public DcMotorEx MOE;
    public DcMotorEx MOD;

    public double highVelocity = 1500;
    public double lowVelocity = 2000;

    double curTargetVelocity = highVelocity;

    double F = 12.6;
    double P = 15;

    double[] stepSizes = {10.0, 1.0, 0.1, 0.01};

    int stepIndex = 1;

    @Override
    public void init() {
        MOE = hardwareMap.get(DcMotorEx.class,"MOE");
        MOE.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);
        MOE.setDirection(DcMotorEx.Direction.REVERSE);

        MOD = hardwareMap.get(DcMotorEx.class,"MOD");
        MOD.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);
        MOD.setDirection(DcMotorEx.Direction.REVERSE);

        PIDFCoefficients pidfCoefficients = new PIDFCoefficients(P,0,0,F);
        MOE.setPIDFCoefficients(DcMotorEx.RunMode.RUN_USING_ENCODER,pidfCoefficients);
        MOD.setPIDFCoefficients(DcMotorEx.RunMode.RUN_USING_ENCODER,pidfCoefficients);
        telemetry.addLine("init complete");

    }

    @Override
    public void loop() {

        if(gamepad1.yWasPressed()){
            if(curTargetVelocity == highVelocity){
                curTargetVelocity = lowVelocity;
            } else {
                curTargetVelocity = highVelocity;
            }
        }

        if (gamepad1.bWasPressed()){
            stepIndex = (stepIndex + 1) % stepSizes.length;
        }

        if (gamepad1.dpadLeftWasPressed()){
            F -= stepSizes[stepIndex];
        }

        if (gamepad1.dpadRightWasPressed()){
            F += stepSizes[stepIndex];
        }

        if (gamepad1.dpadUpWasPressed()){
            P += stepSizes[stepIndex];
        }

        if (gamepad1.dpadDownWasPressed()){
            P -= stepSizes[stepIndex];
        }

        PIDFCoefficients pidfCoefficients = new PIDFCoefficients(P,0,0,F);
        MOE.setPIDFCoefficients(DcMotorEx.RunMode.RUN_USING_ENCODER,pidfCoefficients);
        MOD.setPIDFCoefficients(DcMotorEx.RunMode.RUN_USING_ENCODER,pidfCoefficients);

        MOE.setVelocity(curTargetVelocity);
        MOD.setVelocity(curTargetVelocity);

        double curVelocityE = MOE.getVelocity();
        double curVelocityD = MOE.getVelocity();
        double error = (2 * curTargetVelocity) - (curVelocityE + curVelocityD);

        telemetry.addData("target velocity", curTargetVelocity);
        telemetry.addData("current velocity","%.2f", curVelocityE);
        telemetry.addData("error","%.2f", error);
        telemetry.addLine("----------------------");
        telemetry.addData("tuning P","%.4f (D-Pad U/D)", P);
        telemetry.addData("tuning F","%.4f (D-Pad L/R)", F);
        telemetry.addData("Step Size","%.4f (Right Bumper)", stepSizes[stepIndex]);

        telemetry.update();
    }
}
