package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp
public class TesteServo extends LinearOpMode {
    Servo servo;
    @Override
    public void runOpMode() throws InterruptedException {
        servo = hardwareMap.get(Servo.class,"servo");

        TauraServo tauraServo;

        tauraServo = new TauraServo(servo);

        waitForStart();

        tauraServo.setDirection(Servo.Direction.REVERSE);

        while (opModeIsActive()) {
            if (gamepad1.aWasPressed()) {
                tauraServo.setPosition(1);
            }

            if (gamepad1.bWasPressed()) {
                tauraServo.setPosition(0);
            }
        }
    }
}
