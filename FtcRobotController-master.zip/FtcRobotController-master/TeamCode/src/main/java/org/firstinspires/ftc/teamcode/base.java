package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;
import com.qualcomm.robotcore.hardware.Servo;
import java.util.List;
@TeleOp(name = "base out in cam")
public class base extends LinearOpMode {

    private DcMotor LB;
    private DcMotor RB;
    public DcMotorEx MOE;
    public DcMotorEx MOD;
    private DcMotor LF;
    private DcMotor RF;
    private DcMotor MA;
    DcMotor MI;
    Servo servo;
    TauraServo tauraServo;
    private com.qualcomm.hardware.limelightvision.Limelight3A limelight;

    double TurretPower;
    double x;
    double y;
    double r;
    double vel = 1;
    double tx;
    double ty;
    double ID;
    double ta;
    double highVelocity = 1800;
    double lowVelocity = 0;
    double curTargetVelocity = lowVelocity;
    double F = 12.6;
    double P = 15;
    double distance;
    double APRILTAG_HEIGHT = 74.95;
    double CAMERA_ANGLE = 15;
    double CAMERA_HEIGHT = 34.6;
    double HEIGHT_DIFFERENCE = APRILTAG_HEIGHT - CAMERA_HEIGHT;
    double td;

    @Override
    public void runOpMode() {

        LB = hardwareMap.get(DcMotor.class, "LB");
        RB = hardwareMap.get(DcMotor.class, "RB");
        LF = hardwareMap.get(DcMotor.class, "LF");
        RF = hardwareMap.get(DcMotor.class, "RF");
        MA = hardwareMap.get(DcMotor.class, "MA");
        MI = hardwareMap.get(DcMotor.class, "MI");

        MOE = hardwareMap.get(DcMotorEx.class,"MOE");
        MOE.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);
        MOE.setDirection(DcMotorEx.Direction.REVERSE);

        MOD = hardwareMap.get(DcMotorEx.class,"MOD");
        MOD.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);
        MOD.setDirection(DcMotorEx.Direction.REVERSE);

        PIDFCoefficients pidfCoefficients = new PIDFCoefficients(P,0,0,F);
        MOE.setPIDFCoefficients(DcMotorEx.RunMode.RUN_USING_ENCODER,pidfCoefficients);
        MOD.setPIDFCoefficients(DcMotorEx.RunMode.RUN_USING_ENCODER,pidfCoefficients);

        servo = hardwareMap.get(Servo.class,"servo");
        tauraServo = new TauraServo(servo);

        limelight = hardwareMap.get(com.qualcomm.hardware.limelightvision.Limelight3A.class, "limelight");
        limelight.pipelineSwitch(3);
        limelight.start();

        LB.setDirection(DcMotor.Direction.REVERSE);
        RB.setDirection(DcMotor.Direction.REVERSE);
        MOE.setDirection(DcMotor.Direction.REVERSE);
        MOD.setDirection(DcMotor.Direction.REVERSE);

        waitForStart();
        if (opModeIsActive()) {
            while (opModeIsActive()) {
                outtake();
                intake();
                movimentation();

                telemetry.update();
            }
        }
    }
    private void movimentation() {

        if (gamepad1.a) {
            vel = 0.5;
        }else {
            vel = 1;
        }

        x = -gamepad1.left_stick_x * vel;
        y = gamepad1.left_stick_y * vel;
        r = -gamepad1.right_stick_x * vel;

        LB.setPower(y -x + r);
        LF.setPower(-y - x + r);
        RB.setPower(-y - x - r);
        RF.setPower(y - x - r);
    }
    public void intake(){
        if(gamepad1.right_bumper){
            MA.setPower(1);
        }else {
            MA.setPower(0);
        }

        if(gamepad1.dpad_up & gamepad1.dpad_down){
            if(gamepad1.dpad_up){
                MI.setPower(1);
            }else {
                MI.setPower(-1);
            }
        }else {
            MI.setPower(0);
        }
    }
    private void outtake() {
        flywheel();
        limelight(24);
        torreta();
    }
    public void flywheel() {

        if (gamepad1.yWasPressed()) {
            if (curTargetVelocity == highVelocity) {
                curTargetVelocity = lowVelocity;
            } else {
                curTargetVelocity = highVelocity;
            }
        }

        PIDFCoefficients pidfCoefficients = new PIDFCoefficients(P,0,0,F);
        MOE.setPIDFCoefficients(DcMotorEx.RunMode.RUN_USING_ENCODER, pidfCoefficients);
        MOD.setPIDFCoefficients(DcMotorEx.RunMode.RUN_USING_ENCODER, pidfCoefficients);

        MOE.setVelocity(curTargetVelocity);
        MOD.setVelocity(curTargetVelocity);

        double curVelocityE = MOE.getVelocity();
        double curVelocityD = MOE.getVelocity();
        double error = (2 * curTargetVelocity) - (curVelocityE + curVelocityD);

        telemetry.addData("target velocity", curTargetVelocity);
        telemetry.addData("current velocity", "%.2f", curVelocityE);
        telemetry.addData("error", "%.2f", error);

    }
    public void torreta(){
        TurretPower = (tx / 30) + 0.5;
        tauraServo.setPosition(TurretPower);
    }
    public void limelight(double idAlvo){
        LLResult result = limelight.getLatestResult();

        if(result.isValid()){
            List<LLResultTypes.FiducialResult> fiducialResults = result.getFiducialResults();
            for (LLResultTypes.FiducialResult fr : fiducialResults) {
                ID = fr.getFiducialId();
            }
            if(ID == idAlvo) {

                tx = result.getTx();
                ty = result.getTy();
                ta = result.getTa();

                CalculateDistance(ty);

                telemetry.addData("tx", tx);
                telemetry.addData("ty", ty);
                telemetry.addData("ID", ID);
                telemetry.addData("Area", ta);
                telemetry.addData("distance", distance);
            }
        } else {
            telemetry.addData("Limelight", "No data available");
            tx = 0;
            ty = 0;
            ta = 0;
            td = 0;
        }
    }
    public void CalculateDistance(double ty){
        double ANGLE_DIFFERENCE = CAMERA_ANGLE + ty;
        distance = (HEIGHT_DIFFERENCE / Math.tan(Math.toRadians(ANGLE_DIFFERENCE)));
    }
}