package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;

import java.util.List;

@Disabled
@TeleOp(name = "base out")
public class basePID extends LinearOpMode {

    private DcMotor LB;
    private DcMotor RB;
    public DcMotorEx MOE;
    public DcMotorEx MOD;
    private DcMotor LF;
    private DcMotor RF;
    private DcMotor MT;
    private com.qualcomm.hardware.limelightvision.Limelight3A limelight;

    double OUT;
    double TP;
    double x;
    double y;
    double r;
    double vel = 1;
    double tx;
    double ty;
    int ID;
    double VelMOE;
    double powerFlywheel;
    double highVel = 1500;
    double lowVel = 900;
    double curTarVel = highVel;

    double F = 0;
    double P = 0;

    double[] stepSizes = {10.0, 1.0, 0.1, 0.001, 0.0001};
    int stepIndex = 1;

    @Override
    public void runOpMode() {

        LB = hardwareMap.get(DcMotor.class, "LB");
        RB = hardwareMap.get(DcMotor.class, "RB");
        MOE = hardwareMap.get(DcMotorEx.class, "MOE");
        MOD = hardwareMap.get(DcMotorEx.class, "MOD");
        LF = hardwareMap.get(DcMotor.class, "LF");
        RF = hardwareMap.get(DcMotor.class, "RF");
        MT = hardwareMap.get(DcMotor.class, "MT");

        MOE.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        PIDFCoefficients pidfCoefficients = new PIDFCoefficients(P, 0, 0, F);
        MOE.getPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER);

        limelight = hardwareMap.get(com.qualcomm.hardware.limelightvision.Limelight3A.class, "limelight");


        limelight.pipelineSwitch(3);

        limelight.start();

        waitForStart();
        if (opModeIsActive()) {

            OUT = 0;
            LB.setDirection(DcMotor.Direction.REVERSE);
            RB.setDirection(DcMotor.Direction.REVERSE);
            MOE.setDirection(DcMotor.Direction.REVERSE);
            MOD.setDirection(DcMotor.Direction.REVERSE);
            while (opModeIsActive()) {

                limelight(24);
                outtake();
                movimentation();
                telemetry.update();
            }
        }
    }

    private void movimentation() {

        if (gamepad1.bWasPressed()) {
            if (vel == 1) {
                vel = 0.5;
            } else {
                vel = 1;
            }
        }

        x = -gamepad1.left_stick_x * vel;
        y = gamepad1.left_stick_y * vel;
        r = -gamepad1.right_stick_x * vel;

        LB.setPower(y -x + r);
        LF.setPower(-y - x + r);
        RB.setPower(-y - x - r);
        RF.setPower(y - x - r);
    }

    private void outtake() {
        flywheel();

        TP = tx / 15;
        MT.setPower(TP);
    }

    public void flywheel(){

        VelMOE = MOE.getVelocity();
        telemetry.addData("VelMOE", VelMOE);

        if (gamepad1.yWasPressed()) {
            if (curTarVel == highVel) {
                curTarVel = lowVel;
            } else {
                curTarVel = highVel;
            }
        }

        if (gamepad1.rightBumperWasPressed()) {
            stepIndex = (stepIndex + 1) % stepSizes.length;
        }

        if (gamepad1.dpadLeftWasPressed()) {
            F -= stepSizes[stepIndex];
        }

        if (gamepad1.dpadRightWasPressed()) {
            F += stepSizes[stepIndex];
        }

        if (gamepad1.dpadUpWasPressed()) {
            P += stepSizes[stepIndex];
        }

        if (gamepad1.dpadDownWasPressed()) {
            P -= stepSizes[stepIndex];
        }

        PIDFCoefficients pidfCoefficients = new PIDFCoefficients(P, 0, 0, F);
        MOE.getPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER);

        MOE.setVelocity(curTarVel);

        double curVel = MOE.getVelocity();
        double error = curTarVel - curVel;

        telemetry.addData("target velocity", curTarVel);
        telemetry.addData("current velocity","%.2f", curVel);
        telemetry.addData("error","%.2f", error);
        telemetry.addLine("----------------------");
        telemetry.addData("tuning P","%.4f (D-Pad U/D)", P);
        telemetry.addData("tuning F","%.4f (D-Pad L/R)", F);
        telemetry.addData("Step Size","%.4f (Right Bumper)", stepSizes[stepIndex]);
    }

    public void limelight(int idAlvo){
        LLResult result = limelight.getLatestResult();

        if(result.isValid()){

            List<LLResultTypes.FiducialResult> fiducialResults = result.getFiducialResults();
            for (LLResultTypes.FiducialResult fr : fiducialResults) {
                ID = fr.getFiducialId();
            }

            if(ID == idAlvo) {

                tx = result.getTx();
                ty = result.getTy();

                telemetry.addData("tx", tx);
                telemetry.addData("ty", ty);
                telemetry.addData("ID", ID);
            }
        } else {
            telemetry.addData("Limelight", "No data available");
            tx = 0;
            ty = 0;
        }
    }
}