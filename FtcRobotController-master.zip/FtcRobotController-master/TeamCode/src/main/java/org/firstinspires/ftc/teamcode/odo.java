package org.firstinspires.ftc.teamcode;

import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.hardwareMap;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

@TeleOp (name = "odo")
@Disabled
public class odo extends LinearOpMode {
    DcMotor right;
    DcMotor strafe;
    DcMotor left;

    @Override
    public void runOpMode() {

        left = hardwareMap.get(DcMotor.class, "LF");
        strafe = hardwareMap.get(DcMotor.class, "RB");
        right = hardwareMap.get(DcMotor.class, "LB");

        waitForStart();

        int leftStart = left.getCurrentPosition();
        int rightStart = left.getCurrentPosition();
        int strafeStart = left.getCurrentPosition();

        while (opModeIsActive()){
            telemetry.addData("left", left.getCurrentPosition() - leftStart);
            telemetry.addData("right", right.getCurrentPosition() - rightStart);
            telemetry.addData("strafe", strafe.getCurrentPosition() - strafeStart);
            telemetry.update();
        }
    }
}
